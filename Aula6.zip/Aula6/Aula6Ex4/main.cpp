#include <iostream>
#include <cstdlib>
#include <cstring>

using namespace std;


int main(int argc, char** argv) {
    char palavra1[20], palavra2[20];
    cout<<"Digite a palavra 1: "<<endl;
    cin >>palavra1;
    cout<<"Digite a palavra 2: "<<endl;
    cin>>palavra2;
    cout<<"Unindo Palavra 1 com 3 letras da Palavra 2 temos: "<<strncat(palavra1, palavra2, 3)<< endl;

    
    return 0;
}
