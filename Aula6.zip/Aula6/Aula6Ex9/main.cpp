#include<iostream>
#include <cstdlib>
#include<cstring>

using namespace std;


int main(int argc, char** argv) {
    
    char palavra[20];
    cout<<"Este exemplo substitui caracter de uma palavra."<<endl<<endl;
    cout<<"Digite uma palavra: "<<endl;
    cin>>palavra;
    cout<<"Substituindo "<<strset(palavra,'*')<<endl;

    return 0;
}
