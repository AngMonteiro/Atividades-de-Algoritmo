
#include<iostream>
#include <cstdlib>
#include<cstring>

using namespace std;


int main(int argc, char** argv) {
    
    char palavra[20];
    cout<<"Este exemplo inverte uma palavra."<<endl<<endl;
    cout<<"Digite uma palavra: "<<endl;
    cin>>palavra;
    cout<<"A palavra "<<palavra<<" invertida fica: "<<strrev(palavra)<<endl;

    return 0;
}

