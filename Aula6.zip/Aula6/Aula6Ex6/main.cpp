#include<iostream>
#include <cstdlib>
#include<cstring>

using namespace std;


int main(int argc, char** argv) {
    
    char texto[] = "Este exemplo busca por um determinado caracter dentro de uma string";
    char *ptr;
    cout<<"Procurando por 's' no texto: \n\n"<<texto << endl <<endl;
    ptr=strchr(texto,'s');
    
    if (*ptr){
        cout<<"A letra s apareceu a primeira vez na posição: "<<ptr-texto+1<<endl;
    }
    else{
        cout<<"Letra não encontrada no texto."<<endl;
    }

    return 0;
}

