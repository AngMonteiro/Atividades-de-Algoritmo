#include<iostream>
#include<fstream>
#include <cstdlib>
#include<string.h>
using namespace std;

int main(int argc, char** argv) {
    int n,idade;
    string nome;
    ofstream arq1;
    
    
    cout<<"Quantas pessoas voce deseja fazer o cadastro? "<<endl;
    cin>>n;
    fflush(stdin);
    arq1.open("C:/Users/Aluno/Downloads/Nova pasta/cadastro.txt");
    for(int i=1; i<=n; i++){
        cout<<"Digite o seu primeiro nome: "<<endl;
        getline(cin,nome);
        fflush(stdin);
        cout<<"Digite sua idade"<<endl;
        cin>>idade;
        fflush(stdin);
        arq1<<nome<<", "<<idade<<endl;
    }
    arq1.close();
    
    return 0;
}