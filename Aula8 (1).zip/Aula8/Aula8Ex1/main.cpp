
#include<iostream>
#include <cstdlib>

using namespace std;


int main(int argc, char** argv) {
    int a, b, temp;
    cout<<"Enre dois numeros: "<<endl;
    cin>>a>>b;
    cout<<"Voce entro com "<<a<<" e "<<b<<endl;
    
    temp =a;
    a = b;
    b = temp;
    
    cout<<"Trocados, eles são "<<a <<" e "<<b<<endl;
    

    return 0;
}

