#include<iostream>
#include <cstdlib>
#include<fstream>
#include<cstring>

using namespace std;


int main(int argc, char** argv) {
    
    string abc;
    
    ifstream arq1;
    arq1.open("C:/Users/Aluno/Downloads/Nova pasta/nomes.txt",ios::app);
    
    if(arq1.is_open())
    {
        while (! arq1.eof()){
            getline (arq1,abc);
            cout<<abc<<endl;
        }
        arq1.close();
    }
    else
    {
        cout<<"ERRO: arquivo não foi aberto ou não existe"<<endl;
    }

    return 0;
}

