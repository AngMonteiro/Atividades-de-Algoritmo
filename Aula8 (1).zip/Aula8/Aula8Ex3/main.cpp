#include<iostream>
#include <cstdlib>
#include<fstream>

using namespace std;


int main(int argc, char** argv) {
    
    ofstream arquivo;
    arquivo.open("C:/Users/Aluno/Downloads/Nova pasta/BSIAgora.txt");
    arquivo<<"Nomes da turma A de PRESS"<<endl;
    arquivo<<"Angelo"<<endl;
    arquivo<<"Ivan"<<endl;
    arquivo.close();
    

    return 0;
}

