#include<iostream>
#include <cstdlib>

using namespace std;


void troca(int & x, int & y){
        int temp;
        
           temp =x;
           x = y;
           y = temp;
    }
int main(int argc, char** argv) {
    
        
    int a, b, temp;
    cout<<"Enre dois numeros: "<<endl;
    cin>>a>>b;
    cout<<"Voce entro com "<<a<<" e "<<b<<endl;
    
    troca(a,b);
    
    cout<<"Trocados, eles são "<<a <<" e "<<b<<endl;
    

    return 0;
}