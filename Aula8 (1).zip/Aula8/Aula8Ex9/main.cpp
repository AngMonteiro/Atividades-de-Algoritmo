#include<iostream>
#include <cstdlib>

using namespace std;

int fat(int);

int main(int argc, char** argv) {
    
    int n;
    cout<<"Entre com o valor do fatorial: ";
    cin>>n;
    cout<<"O fatorial e "<<n<<" e "<<fat(n)<<" !";

    return 0;
}
int fat(int n)
{
    if (n>1)
        return n*fat(n-1);
    else return 1;
}

