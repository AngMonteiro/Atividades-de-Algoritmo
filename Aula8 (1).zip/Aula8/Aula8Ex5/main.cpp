#include<iostream>
#include<fstream>
#include <cstdlib>

using namespace std;

int main(int argc, char** argv) {
    
    ofstream arquivo;
    
    arquivo.open("C:/Users/Aluno/Downloads/Nova pasta/arquivoFOR.txt");
    for(int i=0; i<=10; i++){
        arquivo <<"Voce está salvando dados de: "<<i<<endl;
        cout<<"Voce está salvado dados de: "<<i<<endl;
    }
    arquivo.close();

    return 0;
}

