#include<iostream>
#include <cstdlib>
#include<fstream>

using namespace std;


int main(int argc, char** argv) {
    
    ofstream arq1;
    arq1.open("C:/Users/Aluno/Downloads/Nova pasta/nomes.txt",ios::app);
    
    if(arq1.is_open())
    {
        arq1<<"Antônio"<<endl;
        arq1<<"Rose"<<endl;
        arq1.close();
    }
    else
    {
        cout<<"ERRO: arquivo não foi aberto ou não existe"<<endl;
    }

    return 0;
}

