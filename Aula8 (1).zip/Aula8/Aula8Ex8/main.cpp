#include<iostream>
#include <cstdlib>

using namespace std;

float temp(float);

int main(int argc, char** argv) {

    float t;
    
    cout<<"Digite a temperatura em Fahrenheit: "<<endl;
    cin>>t;
    cout<<"A temperatura em Celsius e: "<<temp(t)<<endl;
    
    return 0;
}

float temp(float t){
    float tc;
    tc = ((t-32)/1.8);
    return tc;
}

